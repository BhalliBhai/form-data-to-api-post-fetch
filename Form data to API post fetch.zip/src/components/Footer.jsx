import React from "react";

const Footer = () => {
    return(
        <>
        It's Footer
        </>
    );
}
export default Footer;